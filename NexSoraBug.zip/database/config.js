module.exports = {
  tokens: "8218577733:AAGCZaBwKPkhHxR-chv0fwPklEszfRJAdE0",  // Masukin Bot token kamu
  owners: "7837260212", // Masukin ID Telegram kamu
  port: "2008", // Masukin Port panel kamu 
  ipvps: "kyu-silence.hostingvvip.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1995-1996 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/